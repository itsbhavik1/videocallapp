# Doctor-Patient Video Call App

A React Native application that enables video consultations between doctors and patients.

## Features

- User authentication (Doctor/Patient roles)
- Real-time video calls using Agora SDK
- Mute/unmute audio
- Enable/disable video
- Simple and intuitive UI

## Setup Instructions

1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure Agora:
   - Sign up for an Agora account at https://www.agora.io
   - Create a new project and get the App ID
   - Replace `YOUR_AGORA_APP_ID` in `src/screens/VideoCallScreen.tsx` with your Agora App ID

3. Run the app:
   ```bash
   npm start
   ```

## Login Credentials

- Doctor:
  - Username: doctor
  - Password: 1234

- Patient:
  - Username: patient
  - Password: 5678

## Technical Approach

- Used React Native with TypeScript for type safety
- Implemented Redux for state management
- Integrated Agora SDK for video calling functionality
- Created a clean and modular architecture
- Used React Navigation for routing

## Project Structure

```
src/
├── screens/
│   ├── LoginScreen.tsx
│   ├── HomeScreen.tsx
│   └── VideoCallScreen.tsx
├── store/
│   ├── index.ts
│   ├── authSlice.ts
│   └── callSlice.ts
└── types/
    └── index.ts
```

## Challenges and Solutions

1. **State Management**: 
   - Challenge: Managing complex application state
   - Solution: Implemented Redux with separate slices for auth and call states

2. **Video Call Integration**:
   - Challenge: Integrating real-time video capabilities
   - Solution: Used Agora SDK with proper lifecycle management

3. **User Experience**:
   - Challenge: Creating an intuitive flow for both doctors and patients
   - Solution: Implemented role-based UI and clear navigation paths