import React, { useEffect, useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Alert } from 'react-native';
import RtcEngine, { RtcLocalView, RtcRemoteView, VideoRenderMode } from 'react-native-agora';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { endCall, toggleAudio, toggleVideo } from '../store/callSlice';

const AGORA_APP_ID = 'YOUR_AGORA_APP_ID';

export const VideoCallScreen = ({ navigation }: any) => {
  const dispatch = useDispatch();
  const { isAudioMuted, isVideoMuted } = useSelector((state: RootState) => state.call);
  const [engine, setEngine] = useState<RtcEngine | null>(null);
  const [remoteUid, setRemoteUid] = useState<number | null>(null);

  useEffect(() => {
    initializeAgora();
    return () => {
      engine?.destroy();
    };
  }, []);

  const initializeAgora = async () => {
    try {
      const rtcEngine = await RtcEngine.create(AGORA_APP_ID);
      await rtcEngine.enableVideo();
      
      rtcEngine.addListener('UserJoined', (uid) => {
        setRemoteUid(uid);
      });

      rtcEngine.addListener('UserOffline', () => {
        setRemoteUid(null);
      });

      await rtcEngine.joinChannel(null, 'test-channel', null, 0);
      setEngine(engine);
    } catch (e) {
      console.error(e);
    }
  };

  const handleEndCall = async () => {
    try {
      await engine?.leaveChannel();
      dispatch(endCall());
      navigation.goBack();
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleAudio = async () => {
    try {
      await engine?.muteLocalAudioStream(!isAudioMuted);
      dispatch(toggleAudio());
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleVideo = async () => {
    try {
      await engine?.muteLocalVideoStream(!isVideoMuted);
      dispatch(toggleVideo());
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.videoContainer}>
        <View style={styles.localVideo}>
          <RtcLocalView.SurfaceView
            style={styles.video}
            renderMode={VideoRenderMode.Hidden}
          />
        </View>
        
        {remoteUid ? (
          <View style={styles.remoteVideo}>
            <RtcRemoteView.SurfaceView
              style={styles.video}
              uid={remoteUid}
              renderMode={VideoRenderMode.Hidden}
            />
          </View>
        ) : (
          <View style={styles.remoteVideo}>
            <Text style={styles.waitingText}>Waiting for other participant...</Text>
          </View>
        )}
      </View>

      <View style={styles.controls}>
        <TouchableOpacity
          style={[styles.controlButton, isAudioMuted && styles.mutedButton]}
          onPress={handleToggleAudio}
        >
          <Text style={styles.controlText}>
            {isAudioMuted ? 'Unmute' : 'Mute'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.controlButton, styles.endCallButton]}
          onPress={handleEndCall}
        >
          <Text style={styles.controlText}>End Call</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.controlButton, isVideoMuted && styles.mutedButton]}
          onPress={handleToggleVideo}
        >
          <Text style={styles.controlText}>
            {isVideoMuted ? 'Start Video' : 'Stop Video'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  videoContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  localVideo: {
    flex: 1,
    height: '100%',
  },
  remoteVideo: {
    flex: 1,
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  video: {
    flex: 1,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
  },
  controlButton: {
    padding: 12,
    borderRadius: 25,
    backgroundColor: '#4CAF50',
    width: 100,
    alignItems: 'center',
  },
  endCallButton: {
    backgroundColor: '#f44336',
  },
  mutedButton: {
    backgroundColor: '#666',
  },
  controlText: {
    color: 'white',
    fontWeight: 'bold',
  },
  waitingText: {
    color: 'white',
    fontSize: 16,
  },
});