import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CallState } from '../types';

const initialState: CallState = {
  isInCall: false,
  isCaller: false,
  remoteUid: null,
  isAudioMuted: false,
  isVideoMuted: false,
};

const callSlice = createSlice({
  name: 'call',
  initialState,
  reducers: {
    startCall: (state) => {
      state.isInCall = true;
      state.isCaller = true;
    },
    joinCall: (state, action: PayloadAction<number>) => {
      state.isInCall = true;
      state.isCaller = false;
      state.remoteUid = action.payload;
    },
    endCall: (state) => {
      state.isInCall = false;
      state.isCaller = false;
      state.remoteUid = null;
    },
    toggleAudio: (state) => {
      state.isAudioMuted = !state.isAudioMuted;
    },
    toggleVideo: (state) => {
      state.isVideoMuted = !state.isVideoMuted;
    },
  },
});

export const { startCall, joinCall, endCall, toggleAudio, toggleVideo } = callSlice.actions;
export default callSlice.reducer;