export type UserRole = 'doctor' | 'patient';

export interface User {
  username: string;
  role: UserRole;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface CallState {
  isInCall: boolean;
  isCaller: boolean;
  remoteUid: number | null;
  isAudioMuted: boolean;
  isVideoMuted: boolean;
}